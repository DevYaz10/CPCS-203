package DailyStoreReport;


public class Regular extends Customer {
    // define discountRate=0.05 as constant
    //-------------------------------------
    public Regular()
    {
        
    }
    //--------------------------------------
    public Regular(String name,double purchasesCost)
    {
        super(name,purchasesCost);
    }
    //---------------------------------------
    //override getPurchasesCost as requested
    public double getPurchasesCost()
    {
        
    }
    //---------------------------------------
    //override toString()as requested
    public String toString()
    {
        
    }
}
