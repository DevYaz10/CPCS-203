package DailyStoreReport;

public class VIP extends Customer {
    // define discountRate=0.1 as constant
    // define and initialize GiftCertivacateValue with zero
    //-------------------------------------
    public VIP()
    {
        
    }
    //--------------------------------------
    public VIP(String name,double purchasesCost)
    {
        super(name,purchasesCost);
    }
    //---------------------------------------
    //add GiftCertivacate()that check if the PurchasesCost exceed 1000,
    //then a 100 will be added to GiftCertivacateValue and returned
    
    
    
    
    //---------------------------------------
    //override getPurchasesCost as requested
    public double getPurchasesCost()
    {
        
    }
    //---------------------------------------
    //override toString()as requested
    public String toString()
    {
        
    }
}
