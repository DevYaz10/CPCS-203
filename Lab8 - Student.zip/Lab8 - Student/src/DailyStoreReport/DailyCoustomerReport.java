package DailyStoreReport;

import java.util.*;

public class DailyCoustomerReport {

    public static void main(String[] args) {
        
    }
    
}
