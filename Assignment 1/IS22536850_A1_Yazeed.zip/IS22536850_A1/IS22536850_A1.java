// Name: Yazeed Taifi
// Student ID: 2536850
// Section: IS2
// Assignment Number: 1

import java.io.*;

// Main class - entry point of the Library Borrowing System program
class Main {

    public static void main(String[] args) {
        // Create a LibrarySystem object and process the input file to generate the output
        LibrarySystem system = new LibrarySystem();
        system.processFile("input.txt", "LibraryDB.txt");
    }
}

// LibrarySystem class - manages books, members, fine rules, and borrow records
class LibrarySystem {
    // Arrays to store library data
    private Book[] books;             // Array of Book objects in the library
    private Member[] members;         // Array of Member objects registered in the library
    private double[][] fineRules;     // Ragged 2D array storing fine amounts per fine type and severity level
    private String[] fineCodes;       // Parallel array mapping fine type names to fineRules rows
    private BorrowRecord[] records;   // Array of BorrowRecord objects for all issued borrows

    // Counters to track the current number of elements stored in each array
    private int bookCount = 0;        // Number of books added so far
    private int memberCount = 0;      // Number of members added so far
    private int fineRuleCount = 0;    // Number of fine rule types added so far
    private int recordCount = 0;      // Number of borrow records created so far
    private int nextRecordNo = 1;     // Auto-incrementing record number, starts at 1

    // Reads input file, processes all commands, and writes results to output file
    public void processFile(String inputFile, String outputFile) {
        // Check whether or not the input file exists before attempting to read
        File file = new File(inputFile);
        if (!file.exists()) {
            System.out.println("Error: Input file '" + inputFile + "' not found.");
            return;
        }

        // Open the input file using BufferedReader for efficient line-by-line reading
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            // Read the first line to get array sizes for books and members
            String firstLine = br.readLine();
            if (firstLine == null)
                return;

            // Split the first line by whitespace to extract the two sizes
            String[] firstParts = firstLine.trim().split("\\s+");
            int booksSize = Integer.parseInt(firstParts[0]);    // Maximum number of books
            int membersSize = Integer.parseInt(firstParts[1]);  // Maximum number of members

            // Read the number of fine types (second line) and max borrow records (third line)
            int fineTypes = Integer.parseInt(br.readLine().trim());   // Number of fine rule categories
            int recordsSize = Integer.parseInt(br.readLine().trim()); // Maximum number of borrow records

            // Initialize all arrays with the sizes read from the input file
            books = new Book[booksSize];
            members = new Member[membersSize];
            fineRules = new double[fineTypes][];  // Ragged array: rows created now, columns set later per fine type
            fineCodes = new String[fineTypes];
            records = new BorrowRecord[recordsSize];

            // Read and process each remaining command line from the input file
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();

                // Skip empty lines
                if (line.isEmpty()) {
                    continue;
                }

                // Split the line into parts: first part is the command, rest are arguments
                String[] parts = line.split("\\s+");
                String command = parts[0];

                // Execute the appropriate method based on the command keyword
                switch (command) {
                    case "AddBook":
                        addBook(parts[1], parts[2], parts[3], Integer.parseInt(parts[4]));
                        break;

                    case "AddMember":
                        addMember(parts[1], parts[2], parts[3], Integer.parseInt(parts[4]));
                        break;

                    case "AddFineRule":
                        addFineRule(parts);
                        break;

                    case "IssueBorrow":
                        generateBorrow(parts[1], parts[2], parts[3], Integer.parseInt(parts[4]));
                        break;

                    case "Quit":
                        writeOutput(outputFile);
                        return; // Stop processing after Quit command
                }
            }

            // Write output if end of file is reached without a Quit command
            writeOutput(outputFile);

        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Creates a new Book object and adds it to the books array
    public void addBook(String isbn, String title, String author, int publishYear) {
        books[bookCount++] = new Book(isbn, title, author, publishYear);
    }

    // Creates a new Member object and adds it to the members array
    public void addMember(String memberID, String firstName, String lastName, int birthYear) {
        members[memberCount++] = new Member(memberID, firstName, lastName, birthYear);
    }

    // Adds or updates a fine rule in the ragged fineRules 2D array
    public void addFineRule(String[] parts) {
        String fineCode = parts[1];                  // Fine type name
        int levels = Integer.parseInt(parts[2]);     // Number of severity levels for this fine type

        // Check if this fine code already exists in the fineCodes array
        int index = findFineCodeIndex(fineCode);
        if (index == -1) {
            // New fine code: assign it the next available index
            index = fineRuleCount;
            fineCodes[fineRuleCount++] = fineCode;
        }

        // Create a new row in fineRules for this fine type with the given number of severity levels
        fineRules[index] = new double[levels];
        // Fill each severity level with its fine amount
        for (int i = 0; i < levels; i++) {
            fineRules[index][i] = Double.parseDouble(parts[3 + i]);
        }
    }

    // Creates a new BorrowRecord by matching the book, member, and fine rule, then adds it to records array
    public void generateBorrow(String isbn, String memberID, String fineCode, int severity) {
        // Search for the book and member objects by their identifiers
        Book book = findBookByISBN(isbn);
        Member member = findMemberByID(memberID);

        // Validate that the book and member were found
        if (book == null || member == null) {
            System.out.println("Error: Book or Member not found.");
            return;
        }

        // Validate that the fine code exists and severity is within valid range
        int fineIndex = findFineCodeIndex(fineCode);
        if (fineIndex == -1 || severity < 1 || severity > fineRules[fineIndex].length) {
            System.out.println("Error: Invalid fine code or severity.");
            return;
        }

        // Look up the base fine amount from the ragged array (severity is 1-based, array is 0-based)
        double baseFine = fineRules[fineIndex][severity - 1];

        // Create a new BorrowRecord with a unique record number and store it in the records array
        BorrowRecord record = new BorrowRecord(nextRecordNo++, book, member, fineCode, severity, baseFine);
        records[recordCount++] = record;
    }

    // Prints a single borrow record's full details to the output file using PrintWriter
    public void printBorrow(PrintWriter writer, BorrowRecord record) {
        // Print record header and basic info
        writer.println("=============== Borrow Record Information ===============");
        writer.println("Record No= " + record.getRecordNo());
        writer.println("Fine Code= " + record.getFineCode());
        writer.println("Severity= " + record.getSeverity());
        writer.println("Base Fine= " + String.format("%.1f", record.getBaseFine()));
        writer.println();

        // Print book information from the Book object stored in the record
        writer.println("Book Information");
        writer.println("ISBN= " + record.getBook().getIsbn());
        writer.println("Title= " + record.getBook().getTitle());
        writer.println("Author= " + record.getBook().getAuthor());
        writer.println("Publish Year= " + record.getBook().getPublishYear());
        writer.println();

        // Print member information from the Member object stored in the record
        writer.println("Member Information");
        writer.println("ID= " + record.getMember().getMemberID());
        writer.println("Name= " + record.getMember().getFirstName() + " " + record.getMember().getLastName());
        writer.println("Birth Year= " + record.getMember().getBirthYear());
        writer.println();

        // Print the calculated total fine (base fine + any additional penalties)
        writer.println("Total Fine= " + String.format("%.1f", record.calculateFinalFine()));
        writer.println();
    }

    // Prints a summary table showing the total number of borrows per member
    public void printBorrowsPerMember(PrintWriter writer) {
        writer.println("-------- Total Borrow(s) Per Member --------");
        writer.println("Member ID     Name           Total Borrows");

        // Loop through each member to calculate their total borrows
        for (int i = 0; i < memberCount; i++) {
            Member member = members[i];
            int totalBorrows = 0;

            // Count how many borrow records belong to this member by comparing member IDs
            for (int j = 0; j < recordCount; j++) {
                if (records[j].getMember().getMemberID().equals(member.getMemberID())) {
                    totalBorrows++;
                }
            }

            // Format and print member info with aligned columns
            String fullName = member.getFirstName() + " " + member.getLastName();
            writer.printf("%-13s %-14s %d%n", member.getMemberID(), fullName, totalBorrows);
        }
    }

    // Writes all borrow records followed by the summary report to the output file
    private void writeOutput(String outputFile) {
        // Open the output file with PrintWriter, overwriting any existing content (append=false)
        try (PrintWriter writer = new PrintWriter(new FileWriter(outputFile, false))) {
            // Print all borrow records in the order they were created
            for (int i = 0; i < recordCount; i++) {
                printBorrow(writer, records[i]);
            }
            writer.println();
            // Print the summary table after all individual records
            printBorrowsPerMember(writer);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Searches the books array for a book matching the given ISBN
    private Book findBookByISBN(String isbn) {
        for (int i = 0; i < bookCount; i++) {
            if (books[i].getIsbn().equals(isbn)) {
                return books[i];
            }
        }
        return null;
    }

    // Searches the members array for a member matching the given ID
    private Member findMemberByID(String memberID) {
        for (int i = 0; i < memberCount; i++) {
            if (members[i].getMemberID().equals(memberID)) {
                return members[i];
            }
        }
        return null;
    }

    // Searches the fineCodes array for a matching fine code string
    private int findFineCodeIndex(String fineCode) {
        for (int i = 0; i < fineRuleCount; i++) {
            if (fineCodes[i] != null && fineCodes[i].equals(fineCode)) {
                return i;
            }
        }
        return -1;
    }
}

// Book class - represents a book in the library with ISBN, title, author, and publish year
class Book {
    private String isbn;         // Unique ISBN number of the book
    private String title;        // Title of the book
    private String author;       // Author of the book
    private int publishYear;     // Year the book was published

    // Default constructor - creates a Book with no initial values
    public Book() {
    }

    // Parameterized constructor - creates a Book with all fields set
    public Book(String isbn, String title, String author, int publishYear) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.publishYear = publishYear;
    }

    // Getter: returns the book's ISBN number
    public String getIsbn() {
        return isbn;
    }

    // Setter: sets the book's ISBN number
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    // Getter: returns the book's title
    public String getTitle() {
        return title;
    }

    // Setter: sets the book's title
    public void setTitle(String title) {
        this.title = title;
    }

    // Getter: returns the book's author
    public String getAuthor() {
        return author;
    }

    // Setter: sets the book's author
    public void setAuthor(String author) {
        this.author = author;
    }

    // Getter: returns the book's publish year
    public int getPublishYear() {
        return publishYear;
    }

    // Setter: sets the book's publish year
    public void setPublishYear(int publishYear) {
        this.publishYear = publishYear;
    }

    // Returns a formatted string of the book's information for display
    @Override
    public String toString() {
        return "ISBN= " + isbn + "\n" +
                "Title= " + title + "\n" +
                "Author= " + author + "\n" +
                "Publish Year= " + publishYear;
    }
}

// Member class - represents a library member with ID, name, and birth year
class Member {
    private String memberID;     // Unique ID of the library member
    private String firstName;    // First name of the member
    private String lastName;     // Last name of the member
    private int birthYear;       // Year of birth of the member

    // Default constructor - creates a Member with no initial values
    public Member() {
    }

    // Parameterized constructor - creates a Member with all fields set
    public Member(String memberID, String firstName, String lastName, int birthYear) {
        this.memberID = memberID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthYear = birthYear;
    }

    // Getter: returns the member's ID
    public String getMemberID() {
        return memberID;
    }

    // Setter: sets the member's ID
    public void setMemberID(String memberID) {
        this.memberID = memberID;
    }

    // Getter: returns the member's first name
    public String getFirstName() {
        return firstName;
    }

    // Setter: sets the member's first name
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // Getter: returns the member's last name
    public String getLastName() {
        return lastName;
    }

    // Setter: sets the member's last name
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // Getter: returns the member's birth year
    public int getBirthYear() {
        return birthYear;
    }

    // Setter: sets the member's birth year
    public void setBirthYear(int birthYear) {
        this.birthYear = birthYear;
    }

    // Returns a formatted string of the member's information for display
    // Output: multi-line string with ID, full name, and birth year
    @Override
    public String toString() {
        return "ID= " + memberID + "\n" +
                "Name= " + firstName + " " + lastName + "\n" +
                "Birth Year= " + birthYear;
    }
}

// BorrowRecord class - represents a borrowing transaction linking a book and member with fine info
class BorrowRecord {
    private int recordNo;        // Unique record number for this borrow (auto-incremented)
    private Book book;           // Book object associated with this borrow record
    private Member member;       // Member object who borrowed the book
    private String fineCode;     // Fine type code (e.g. "LateReturn", "DamagedBook", "LostBook")
    private int severity;        // Severity level of the fine (1-based)
    private double baseFine;     // Base fine amount from the fine rules array

    // Default constructor - creates a BorrowRecord with no initial values
    public BorrowRecord() {
    }

    // Parameterized constructor - creates a BorrowRecord with all fields set
    public BorrowRecord(int recordNo, Book book, Member member, String fineCode, int severity, double baseFine) {
        this.recordNo = recordNo;
        this.book = book;
        this.member = member;
        this.fineCode = fineCode;
        this.severity = severity;
        this.baseFine = baseFine;
    }

    // Calculates the total fine by adding additional penalties to the base fine
    public double calculateFinalFine() {
        double totalFine = baseFine;

        // Calculate member's age based on current year
        int currentYear = 2026;
        int age = currentYear - member.getBirthYear();

        // Penalty for underage member (below 18 years old)
        if (age < 18) {
            totalFine += 100;
        }

        // Penalty for old book (published before year 2000)
        if (book.getPublishYear() < 2000) {
            totalFine += 50;
        }

        return totalFine;
    }

    // Getter: returns the borrow record number
    public int getRecordNo() {
        return recordNo;
    }

    // Setter: sets the borrow record number
    public void setRecordNo(int recordNo) {
        this.recordNo = recordNo;
    }

    // Getter: returns the Book object associated with this record
    public Book getBook() {
        return book;
    }

    // Setter: sets the Book object for this record
    public void setBook(Book book) {
        this.book = book;
    }

    // Getter: returns the Member object associated with this record
    public Member getMember() {
        return member;
    }

    // Setter: sets the Member object for this record
    public void setMember(Member member) {
        this.member = member;
    }

    // Getter: returns the fine code string
    public String getFineCode() {
        return fineCode;
    }

    // Setter: sets the fine code string
    public void setFineCode(String fineCode) {
        this.fineCode = fineCode;
    }

    // Getter: returns the severity level
    public int getSeverity() {
        return severity;
    }

    // Setter: sets the severity level
    public void setSeverity(int severity) {
        this.severity = severity;
    }

    // Getter: returns the base fine amount
    public double getBaseFine() {
        return baseFine;
    }

    // Setter: sets the base fine amount
    public void setBaseFine(double baseFine) {
        this.baseFine = baseFine;
    }

    // Returns a formatted string of the full borrow record for display
    // Output: multi-line string with record info, book info, member info, and total fine
    @Override
    public String toString() {
        return "=============== Borrow Record Information ===============\n" +
                "Record No= " + recordNo + "\n" +
                "Fine Code= " + fineCode + "\n" +
                "Severity= " + severity + "\n" +
                "Base Fine= " + String.format("%.1f", baseFine) + "\n\n" +
                "Book Information\n" +
                book.toString() + "\n\n" +
                "Member Information\n" +
                member.toString() + "\n\n" +
                "Total Fine= " + String.format("%.1f", calculateFinalFine()) + "\n";
    }
}